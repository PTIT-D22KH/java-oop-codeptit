package HandlingExceptionThrowsCatch;

public class DiemException extends Exception{


    public DiemException(String message) {
        super(message);
    }
}
