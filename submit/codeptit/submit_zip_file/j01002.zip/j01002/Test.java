package j01002;
import java.util.*;
public class Test {
    // public static Scanner input = new Scanner(System.in);
    public long testCase(Scanner input) {
        int n = input.nextInt();
        long res = (long) n * (n + 1) / 2;
        return res;
    }

}
