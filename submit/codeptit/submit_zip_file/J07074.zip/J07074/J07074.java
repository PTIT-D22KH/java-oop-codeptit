package J07074;

public class J07074 {
    public static void main(String[] args) {
        // Write your code here
    }
}
