package J07074;

public class Section {
    private String groupId, courseId;
}
