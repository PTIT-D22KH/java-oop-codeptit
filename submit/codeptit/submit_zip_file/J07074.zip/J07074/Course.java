package J07074;

public class Course {
    private String id, name;
    private int numOfCredits;
}
