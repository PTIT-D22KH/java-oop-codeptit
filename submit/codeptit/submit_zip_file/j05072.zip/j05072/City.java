package j05072;

public class City {
    private String name;
    private long price;
    public City(String name, long price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }
    public long getPrice() {
        return price;
    }
}
