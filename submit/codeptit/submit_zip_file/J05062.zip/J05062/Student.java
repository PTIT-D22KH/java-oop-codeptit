package J05062;

public class Student {
    private String name, result;
    private double gpa;
    private int rlScore;
    public Student(String name, String score) {
        this.name = name;
        String a[] = score.trim().split("\\s+");
        this.gpa = 
    }

    
}
