package J05062;

public class J05062 {
    public static void main(String[] args) {
        // Write your code here
    }
}
