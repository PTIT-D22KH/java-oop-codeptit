package J04019;

public class Point {
    
}
