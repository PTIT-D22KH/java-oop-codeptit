package J07009;

import java.util.Set;
import java.util.TreeSet;

public class IntSet {
    private Set<Integer> se = new TreeSet<>();
    
}
