package J07009;

import java.util.Set;
import java.util.TreeSet;

public class IntSet {
    private Set<Integer> se = new TreeSet<>();
    public IntSet(int a[]) {
        for (int i = 0; i < a.length; i++) {
            
        }
    }
}
