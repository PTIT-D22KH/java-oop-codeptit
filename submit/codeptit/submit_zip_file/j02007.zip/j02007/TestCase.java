package j02007;

import java.util.Scanner;

public class TestCase {
    private static int cnt = 0;
    public TestCase() {
        cnt++;
    }
    public void testCase(){
        System.out.printf("Test %d: \n", cnt);
    }
}
