package j07007;

import java.io.IOException;

public class j07007 {
    public static void main(String[] args) throws IOException {
        // Write your code here
        // WordSet s = new WordSet("j07007/VANBAN.in");
        WordSet s = new WordSet("VANBAN.in");
        System.out.println(s);
    }
}
