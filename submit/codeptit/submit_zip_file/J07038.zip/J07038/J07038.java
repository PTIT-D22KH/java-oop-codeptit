package J07038;

public class J07038 {
    public static void main(String[] args) {
        // Write your code here
    }
}
