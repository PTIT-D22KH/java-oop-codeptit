package J07038;

public class Student {
    private String id, name, className, email;


    public Student(String id, String name, String className, String email) {
        this.id = id;
        this.name = name;
        this.className = className;
        this.email = email;
    }
}
