package J07047;

public class J07047 {
    public static void main(String[] args) {
        // Write your code here
    }
}
