package J07084;

public class Student {
    private String name, startTime, endTime;
    private long duration;
}
