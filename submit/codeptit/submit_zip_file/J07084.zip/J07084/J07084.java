package J07084;

public class J07084 {
    public static void main(String[] args) {
        // Write your code here
    }
}
