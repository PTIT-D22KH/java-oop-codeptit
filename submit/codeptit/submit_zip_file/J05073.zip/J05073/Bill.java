package J05073;

public class Bill {
    private String id;
    private double totalPrice;
    private long numBuy;

    public Bill(String s) {
        String a[] = s.trim().split("\\s+");
        
    }
}
