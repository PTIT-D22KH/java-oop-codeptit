package J05073;

public class J05073 {
    public static void main(String[] args) {
        // Write your code here
    }
}
