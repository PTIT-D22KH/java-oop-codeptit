package J05073;

public class Product {
    private String id, firstId, lastId;
    private double tax, shippingFee;

    private long singlePrice;

    
}
