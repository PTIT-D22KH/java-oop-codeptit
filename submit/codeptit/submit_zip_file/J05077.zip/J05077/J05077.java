package J05077;

public class J05077 {
    public static void main(String[] args) {
        // Write your code here
    }
}
