package J05077;

public class Department {
    private String id, name;

    
}
