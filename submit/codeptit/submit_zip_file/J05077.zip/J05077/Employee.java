package J05077;

public class Employee {
    private String id, name;
    private Department department;
    private long basicSalary, numDays;
}
